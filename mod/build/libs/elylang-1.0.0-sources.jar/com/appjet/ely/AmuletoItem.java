package com.appjet.ely;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;

/**
 * Amuleto del Corazón: al usarlo abre el diálogo con Ely.
 * También admite clic derecho en el aire desde el cliente.
 */
public class AmuletoItem extends class_1792 {

    public AmuletoItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 enMano = user.method_5998(hand);
        if (!world.method_8608() && user instanceof class_3222 player) {
            ElyDialogue.abrirMenu(player);
        }
        return class_1271.method_22427(enMano);
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return true;
    }
}
