package com.appjet.ely;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3222;
import net.minecraft.class_5250;

/**
 * Árbol de diálogo de Ely. Cada nodo tiene una frase y varias respuestas;
 * las respuestas se eligen con clic en el chat o con /ely elegir <nodo> <indice>.
 */
public final class ElyDialogue {

    public record Opcion(String clave, int afinidad, String siguiente) {
    }

    public record Nodo(String clave, boolean usaGenero, List<Opcion> opciones) {
    }

    private static final Map<String, Nodo> NODOS = new LinkedHashMap<>();

    static {
        nodo("raiz", "elylang.nodo.raiz", false,
            new Opcion("elylang.opc.raiz.1", 2, "quien"),
            new Opcion("elylang.opc.raiz.2", 2, "saludo"),
            new Opcion("elylang.opc.raiz.3", 2, "bosque"),
            new Opcion("elylang.opc.raiz.4", 3, "pasado"),
            new Opcion("elylang.opc.raiz.5", 3, "nosotros"),
            new Opcion("elylang.opc.raiz.6", 3, "futuro"),
            new Opcion("elylang.opc.raiz.7", 2, "adios"));

        nodo("quien", "elylang.presentacion", true,
            new Opcion("elylang.opc.quien.1", 4, "saludo"),
            new Opcion("elylang.opc.quien.2", 3, "pasado"));

        nodo("saludo", "elylang.nodo.saludo", false,
            new Opcion("elylang.opc.saludo.1", 4, "adios"),
            new Opcion("elylang.opc.saludo.2", 5, "cuidado"),
            new Opcion("elylang.opc.saludo.3", 3, "adios"));

        nodo("cuidado", "elylang.nodo.cuidado", false,
            new Opcion("elylang.opc.cuidado.1", 6, "fin"),
            new Opcion("elylang.opc.cuidado.2", 8, "fin"));

        nodo("bosque", "elylang.nodo.bosque", false,
            new Opcion("elylang.opc.bosque.1", 4, "nosotros"),
            new Opcion("elylang.opc.bosque.2", 3, "arbol"),
            new Opcion("elylang.opc.bosque.3", 2, "fin"));

        nodo("arbol", "elylang.nodo.arbol", false,
            new Opcion("elylang.opc.arbol.1", 5, "fin"));

        nodo("pasado", "elylang.nodo.pasado", false,
            new Opcion("elylang.opc.pasado.1", 6, "fin"),
            new Opcion("elylang.opc.pasado.2", 3, "fin"),
            new Opcion("elylang.opc.pasado.3", 1, "fin"));

        nodo("nosotros", "elylang.nodo.nosotros", false,
            new Opcion("elylang.opc.nosotros.1", 7, "fin"),
            new Opcion("elylang.opc.nosotros.2", 2, "fin"),
            new Opcion("elylang.opc.nosotros.3", -5, "fin"));

        nodo("futuro", "elylang.nodo.futuro", false,
            new Opcion("elylang.opc.futuro.1", 8, "fin"),
            new Opcion("elylang.opc.futuro.2", 5, "fin"),
            new Opcion("elylang.opc.futuro.3", 1, "fin"));

        nodo("adios", "elylang.nodo.adios", false,
            new Opcion("elylang.opc.adios.1", 3, "fin"));

        nodo("fin", "elylang.nodo.fin", false,
            new Opcion("elylang.opc.fin.1", 0, ""));
    }

    private ElyDialogue() {
    }

    /** Identificadores de nodo, para sugerencias de comandos. */
    public static java.util.Set<String> ids() {
        return NODOS.keySet();
    }

    private static void nodo(String id, String clave, boolean usaGenero, Opcion... opciones) {
        NODOS.put(id, new Nodo(clave, usaGenero, List.of(opciones)));
    }

    public static void abrirMenu(class_3222 jugador) {
        ElyState estado = ElyState.get(jugador.method_5682());
        if (!estado.tieneGenero(jugador.method_5667())) {
            ElyJoin.pedirGenero(jugador);
        }
        mostrar(jugador, "raiz");
        jugador.method_7353(class_2561.method_43471("elylang.menu.ayuda").method_27692(class_124.field_1063), false);
    }

    public static void mostrar(class_3222 jugador, String id) {
        if (id == null || id.isEmpty() || !NODOS.containsKey(id)) {
            jugador.method_7353(class_2561.method_43471("elylang.cierre").method_27692(class_124.field_1063), false);
            return;
        }

        Nodo nodo = NODOS.get(id);
        ElyState estado = ElyState.get(jugador.method_5682());
        int afinidad = estado.afinidad(jugador.method_5667());

        jugador.method_7353(
            class_2561.method_43469("elylang.cabecera", class_2561.method_43471(estadoClave(afinidad)), String.valueOf(afinidad))
                .method_27692(class_124.field_1076),
            false
        );

        String claveTexto = nodo.usaGenero()
            ? nodo.clave() + "." + estado.genero(jugador.method_5667())
            : nodo.clave();

        jugador.method_7353(class_2561.method_43471(claveTexto).method_27692(class_124.field_1068), false);

        List<Opcion> opciones = nodo.opciones();
        for (int i = 0; i < opciones.size(); i++) {
            Opcion opcion = opciones.get(i);
            String comando = "/ely elegir " + id + " " + i;
            class_5250 linea = class_2561.method_43470("  ▸ ").method_27692(class_124.field_1063)
                .method_10852(class_2561.method_43471(opcion.clave()).method_27692(class_124.field_1075));
            linea.method_27694(estilo -> estilo
                .method_10958(new class_2558(class_2558.class_2559.field_11750, comando))
                .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43471("elylang.hover.elegir"))));
            jugador.method_7353(linea, false);
        }
    }

    public static void elegir(class_3222 jugador, String id, int indice) {
        Nodo nodo = NODOS.get(id);
        if (nodo == null) {
            mostrar(jugador, "raiz");
            return;
        }
        if (indice < 0 || indice >= nodo.opciones().size()) {
            mostrar(jugador, id);
            return;
        }

        Opcion opcion = nodo.opciones().get(indice);
        ElyState estado = ElyState.get(jugador.method_5682());
        int nueva = estado.sumarAfinidad(jugador.method_5667(), opcion.afinidad());

        jugador.method_7353(
            class_2561.method_43470("▸ ").method_27692(class_124.field_1063)
                .method_10852(class_2561.method_43471(opcion.clave()).method_27692(class_124.field_1080)),
            false
        );

        if (opcion.afinidad() != 0) {
            jugador.method_7353(
                class_2561.method_43469(
                    "elylang.dialogo.afinidad",
                    opcion.afinidad() > 0 ? "+" : "",
                    opcion.afinidad(),
                    nueva
                ).method_27692(opcion.afinidad() > 0 ? class_124.field_1076 : class_124.field_1061),
                false
            );
        }

        mostrar(jugador, opcion.siguiente());
    }

    public static String estadoClave(int afinidad) {
        if (afinidad >= 95) {
            return "elylang.estado.4";
        }
        if (afinidad >= 75) {
            return "elylang.estado.3";
        }
        if (afinidad >= 50) {
            return "elylang.estado.2";
        }
        if (afinidad >= 25) {
            return "elylang.estado.1";
        }
        return "elylang.estado.0";
    }
}
