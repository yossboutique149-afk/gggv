package com.appjet.ely;

import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_3222;
import net.minecraft.class_5250;

/** Entrega del amuleto y elección de género al empezar el mundo. */
public final class ElyJoin {

    private ElyJoin() {
    }

    public static void alEntrar(class_3222 jugador) {
        ElyState estado = ElyState.get(jugador.method_5682());

        if (!estado.amuletoEntregado(jugador.method_5667())) {
            estado.marcarAmuleto(jugador.method_5667());
            jugador.method_31548().method_7394(new class_1799(ElyItems.AMULETO));
            jugador.method_7353(class_2561.method_43471("elylang.bienvenida").method_27692(class_124.field_1076), false);
        } else if (!tieneAmuleto(jugador)) {
            jugador.method_7353(
                class_2561.method_43470("▸ ").method_27692(class_124.field_1063)
                    .method_10852(class_2561.method_43471("elylang.menu.ayuda").method_27692(class_124.field_1080)),
                false
            );
        }

        if (!estado.tieneGenero(jugador.method_5667())) {
            pedirGenero(jugador);
        }
    }

    /** El jugador define el género de su compañera con botones clicables. */
    public static void pedirGenero(class_3222 jugador) {
        jugador.method_7353(class_2561.method_43471("elylang.genero.pedir").method_27692(class_124.field_1076), false);
        jugador.method_7353(opcion("elylang.genero.opcion.femenino", "/ely genero femenino"), false);
        jugador.method_7353(opcion("elylang.genero.opcion.masculino", "/ely genero masculino"), false);
        jugador.method_7353(opcion("elylang.genero.opcion.neutro", "/ely genero neutro"), false);
    }

    private static class_5250 opcion(String clave, String comando) {
        class_5250 linea = class_2561.method_43470("  ▸ ").method_27692(class_124.field_1063)
            .method_10852(class_2561.method_43471(clave).method_27692(class_124.field_1075));
        linea.method_27694(estilo -> estilo
            .method_10958(new class_2558(class_2558.class_2559.field_11750, comando))
            .method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43471("elylang.hover.elegir"))));
        return linea;
    }

    private static boolean tieneAmuleto(class_3222 jugador) {
        for (int i = 0; i < jugador.method_31548().method_5439(); i++) {
            if (jugador.method_31548().method_5438(i).method_31574(ElyItems.AMULETO)) {
                return true;
            }
        }
        return false;
    }
}
