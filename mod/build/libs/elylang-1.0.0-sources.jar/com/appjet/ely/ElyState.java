package com.appjet.ely;

import net.minecraft.class_18;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Estado persistente del mod: afinidad, género elegido, confirmación de edad,
 * entrega del amuleto y última noche de pasión, por jugador.
 */
public class ElyState extends class_18 {
    private static final String CLAVE = "elylang_companera";

    /** Tipo de estado persistente que registra el gestor de estado del mundo. */
    public static final class_18.class_8645<ElyState> TIPO =
        new class_18.class_8645<>(ElyState::new, ElyState::fromNbt, null);

    public static final int AFINIDAD_INICIAL = 20;
    public static final int AFINIDAD_MAXIMA = 100;
    public static final long RECARGA_INTIMIDAD = 24000L;

    private final Map<UUID, Integer> afinidad = new HashMap<>();
    private final Map<UUID, String> generos = new HashMap<>();
    private final Map<UUID, Boolean> amuletoEntregado = new HashMap<>();
    private final Map<UUID, Boolean> adultos = new HashMap<>();
    private final Map<UUID, Long> ultimaIntimidad = new HashMap<>();

    public static ElyState get(MinecraftServer server) {
        return server.method_30002()
            .method_17983()
            .method_17924(TIPO, CLAVE);
    }

    // --- afinidad -----------------------------------------------------------

    public int afinidad(UUID id) {
        return afinidad.getOrDefault(id, AFINIDAD_INICIAL);
    }

    public void setAfinidad(UUID id, int valor) {
        afinidad.put(id, Math.max(0, Math.min(AFINIDAD_MAXIMA, valor)));
        method_80();
    }

    public int sumarAfinidad(UUID id, int delta) {
        int nuevo = Math.max(0, Math.min(AFINIDAD_MAXIMA, afinidad(id) + delta));
        afinidad.put(id, nuevo);
        method_80();
        return nuevo;
    }

    // --- género -------------------------------------------------------------

    public String genero(UUID id) {
        return generos.getOrDefault(id, "femenino");
    }

    public boolean tieneGenero(UUID id) {
        return generos.containsKey(id);
    }

    public boolean setGenero(UUID id, String valor) {
        if (!valor.equals("femenino") && !valor.equals("masculino") && !valor.equals("neutro")) {
            return false;
        }
        generos.put(id, valor);
        method_80();
        return true;
    }

    // --- resto de banderas --------------------------------------------------

    public boolean amuletoEntregado(UUID id) {
        return amuletoEntregado.getOrDefault(id, false);
    }

    public void marcarAmuleto(UUID id) {
        amuletoEntregado.put(id, true);
        method_80();
    }

    public boolean esAdulto(UUID id) {
        return adultos.getOrDefault(id, false);
    }

    public void confirmarAdulto(UUID id) {
        adultos.put(id, true);
        method_80();
    }

    public long ultimaIntimidad(UUID id) {
        return ultimaIntimidad.getOrDefault(id, Long.MIN_VALUE / 2);
    }

    public void marcarIntimidad(UUID id, long tiempo) {
        ultimaIntimidad.put(id, tiempo);
        method_80();
    }

    // --- serialización ------------------------------------------------------

    public static ElyState fromNbt(class_2487 nbt, class_7225.class_7874 lookup) {
        ElyState estado = new ElyState();
        leerEnteros(nbt, "afinidad", estado.afinidad);
        leerBooleanos(nbt, "amuleto", estado.amuletoEntregado);
        leerBooleanos(nbt, "adultos", estado.adultos);
        leerLargos(nbt, "intimidad", estado.ultimaIntimidad);
        leerTextos(nbt, "generos", estado.generos);
        return estado;
    }

    @Override
    public class_2487 method_75(class_2487 nbt, class_7225.class_7874 lookup) {
        nbt.method_10566("afinidad", escribirEnteros(afinidad));
        nbt.method_10566("amuleto", escribirBooleanos(amuletoEntregado));
        nbt.method_10566("adultos", escribirBooleanos(adultos));
        nbt.method_10566("intimidad", escribirLargos(ultimaIntimidad));
        nbt.method_10566("generos", escribirTextos(generos));
        return nbt;
    }

    private static class_2487 escribirEnteros(Map<UUID, Integer> mapa) {
        class_2487 compuesto = new class_2487();
        mapa.forEach((id, valor) -> compuesto.method_10569(id.toString(), valor));
        return compuesto;
    }

    private static class_2487 escribirBooleanos(Map<UUID, Boolean> mapa) {
        class_2487 compuesto = new class_2487();
        mapa.forEach((id, valor) -> compuesto.method_10556(id.toString(), valor));
        return compuesto;
    }

    private static class_2487 escribirLargos(Map<UUID, Long> mapa) {
        class_2487 compuesto = new class_2487();
        mapa.forEach((id, valor) -> compuesto.method_10544(id.toString(), valor));
        return compuesto;
    }

    private static class_2487 escribirTextos(Map<UUID, String> mapa) {
        class_2487 compuesto = new class_2487();
        mapa.forEach((id, valor) -> compuesto.method_10582(id.toString(), valor));
        return compuesto;
    }

    private static void leerEnteros(class_2487 nbt, String clave, Map<UUID, Integer> destino) {
        if (!nbt.method_10545(clave)) {
            return;
        }
        class_2487 compuesto = nbt.method_10562(clave);
        for (String k : compuesto.method_10541()) {
            UUID id = parsear(k);
            if (id != null) {
                destino.put(id, compuesto.method_10550(k));
            }
        }
    }

    private static void leerBooleanos(class_2487 nbt, String clave, Map<UUID, Boolean> destino) {
        if (!nbt.method_10545(clave)) {
            return;
        }
        class_2487 compuesto = nbt.method_10562(clave);
        for (String k : compuesto.method_10541()) {
            UUID id = parsear(k);
            if (id != null) {
                destino.put(id, compuesto.method_10577(k));
            }
        }
    }

    private static void leerLargos(class_2487 nbt, String clave, Map<UUID, Long> destino) {
        if (!nbt.method_10545(clave)) {
            return;
        }
        class_2487 compuesto = nbt.method_10562(clave);
        for (String k : compuesto.method_10541()) {
            UUID id = parsear(k);
            if (id != null) {
                destino.put(id, compuesto.method_10537(k));
            }
        }
    }

    private static void leerTextos(class_2487 nbt, String clave, Map<UUID, String> destino) {
        if (!nbt.method_10545(clave)) {
            return;
        }
        class_2487 compuesto = nbt.method_10562(clave);
        for (String k : compuesto.method_10541()) {
            UUID id = parsear(k);
            if (id != null) {
                destino.put(id, compuesto.method_10558(k));
            }
        }
    }

    private static UUID parsear(String texto) {
        try {
            return UUID.fromString(texto);
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
