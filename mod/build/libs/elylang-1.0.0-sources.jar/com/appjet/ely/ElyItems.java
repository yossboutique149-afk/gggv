package com.appjet.ely;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

/** Registro de los objetos del mod. */
public final class ElyItems {

    /** Objeto para dialogar con Ely. */
    public static final class_1792 AMULETO = new AmuletoItem(
        new class_1792.class_1793().method_7889(1).method_7894(class_1814.field_8903)
    );

    private ElyItems() {
    }

    public static void register() {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(ElyMod.MOD_ID, "amuleto_corazon"), AMULETO);
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> entries.method_45421(AMULETO));
    }
}
