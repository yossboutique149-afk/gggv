package com.appjet.ely;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

/** Comandos del mod: /ely ... */
public final class ElyCommands {

    private ElyCommands() {
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> registrar(dispatcher));
    }

    private static void registrar(CommandDispatcher<class_2168> dispatcher) {
        SuggestionProvider<class_2168> generos = (contexto, builder) ->
            class_2172.method_9253(new String[]{"femenino", "masculino", "neutro"}, builder);

        SuggestionProvider<class_2168> nodos = (contexto, builder) ->
            class_2172.method_9265(ElyDialogue.ids(), builder);

        dispatcher.register(class_2170.method_9247("ely")
            .executes(ElyCommands::menu)
            .then(class_2170.method_9247("menu").executes(ElyCommands::menu))
            .then(class_2170.method_9247("ayuda").executes(ElyCommands::ayuda))
            .then(class_2170.method_9247("estado").executes(ElyCommands::estado))
            .then(class_2170.method_9247("genero")
                .then(class_2170.method_9244("valor", StringArgumentType.word())
                    .suggests(generos)
                    .executes(ElyCommands::genero)))
            .then(class_2170.method_9247("elegir")
                .then(class_2170.method_9244("nodo", StringArgumentType.word())
                    .suggests(nodos)
                    .then(class_2170.method_9244("indice", IntegerArgumentType.integer(0, 20))
                        .executes(ElyCommands::elegir))))
            .then(class_2170.method_9247("picar").executes(ElyCommands::picar))
            .then(class_2170.method_9247("minar").executes(ElyCommands::minar))
            .then(class_2170.method_9247("proteger").executes(ElyCommands::proteger))
            .then(class_2170.method_9247("flor").executes(ElyCommands::flor))
            .then(class_2170.method_9247("acariciar").executes(ElyCommands::acariciar))
            .then(class_2170.method_9247("intimidad").executes(ElyCommands::intimidad))
            .then(class_2170.method_9247("afinidad")
                .then(class_2170.method_9244("valor", IntegerArgumentType.integer(0, 100))
                    .executes(ElyCommands::afinidad)))
            .then(class_2170.method_9247("adulto")
                .executes(ElyCommands::avisoAdulto)
                .then(class_2170.method_9247("confirmo").executes(ElyCommands::adulto)))
        );
    }

    // --- manejadores --------------------------------------------------------

    private static int menu(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        ElyDialogue.abrirMenu(jugador(contexto));
        return 1;
    }

    private static int ayuda(CommandContext<class_2168> contexto) {
        class_2168 fuente = contexto.getSource();
        fuente.method_9226(() -> class_2561.method_43471("elylang.ayuda.1"), false);
        fuente.method_9226(() -> class_2561.method_43471("elylang.ayuda.2"), false);
        fuente.method_9226(() -> class_2561.method_43471("elylang.ayuda.3"), false);
        fuente.method_9226(() -> class_2561.method_43471("elylang.ayuda.4"), false);
        fuente.method_9226(() -> class_2561.method_43471("elylang.ayuda.5"), false);
        fuente.method_9226(() -> class_2561.method_43471("elylang.ayuda.6"), false);
        fuente.method_9226(() -> class_2561.method_43471("elylang.ayuda.7"), false);
        return 1;
    }

    private static int estado(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        class_3222 jugador = jugador(contexto);
        ElyState estado = ElyState.get(jugador.method_5682());
        int afinidad = estado.afinidad(jugador.method_5667());

        jugador.method_7353(class_2561.method_43469("elylang.cabecera",
            class_2561.method_43471(ElyDialogue.estadoClave(afinidad)), String.valueOf(afinidad))
            .method_27692(class_124.field_1076), false);
        jugador.method_7353(class_2561.method_43469("elylang.estado.genero", estado.genero(jugador.method_5667()))
            .method_27692(class_124.field_1080), false);
        jugador.method_7353(class_2561.method_43469("elylang.estado.adulto", estado.esAdulto(jugador.method_5667()))
            .method_27692(class_124.field_1080), false);
        return 1;
    }

    private static int genero(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        class_3222 jugador = jugador(contexto);
        String valor = StringArgumentType.getString(contexto, "valor");
        ElyState estado = ElyState.get(jugador.method_5682());

        if (!estado.setGenero(jugador.method_5667(), valor)) {
            contexto.getSource().method_9213(class_2561.method_43471("elylang.genero.invalido"));
            return 0;
        }

        jugador.method_7353(class_2561.method_43469("elylang.genero.ok", valor).method_27692(class_124.field_1076), false);
        ElyDialogue.mostrar(jugador, "quien");
        return 1;
    }

    private static int elegir(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        class_3222 jugador = jugador(contexto);
        String nodo = StringArgumentType.getString(contexto, "nodo");
        int indice = IntegerArgumentType.getInteger(contexto, "indice");
        ElyDialogue.elegir(jugador, nodo, indice);
        return 1;
    }

    private static int picar(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        ElyActions.picar(jugador(contexto));
        return 1;
    }

    private static int minar(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        ElyActions.minar(jugador(contexto));
        return 1;
    }

    private static int proteger(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        ElyActions.proteger(jugador(contexto));
        return 1;
    }

    private static int flor(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        ElyActions.flor(jugador(contexto));
        return 1;
    }

    private static int acariciar(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        ElyActions.acariciar(jugador(contexto));
        return 1;
    }

    private static int intimidad(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        ElyActions.intimidad(jugador(contexto));
        return 1;
    }

    private static int afinidad(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        class_3222 jugador = jugador(contexto);
        int valor = IntegerArgumentType.getInteger(contexto, "valor");
        ElyState estado = ElyState.get(jugador.method_5682());
        estado.setAfinidad(jugador.method_5667(), valor);
        jugador.method_7353(class_2561.method_43469("elylang.afinidad.fijada", valor).method_27692(class_124.field_1076), false);
        return 1;
    }

    private static int avisoAdulto(CommandContext<class_2168> contexto) {
        contexto.getSource().method_9226(() -> class_2561.method_43471("elylang.adulto.aviso").method_27692(class_124.field_1054), false);
        return 1;
    }

    private static int adulto(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        class_3222 jugador = jugador(contexto);
        ElyState.get(jugador.method_5682()).confirmarAdulto(jugador.method_5667());
        jugador.method_7353(class_2561.method_43471("elylang.adulto.ok").method_27692(class_124.field_1060), false);
        return 1;
    }

    private static class_3222 jugador(CommandContext<class_2168> contexto) throws CommandSyntaxException {
        return contexto.getSource().method_9207();
    }
}
