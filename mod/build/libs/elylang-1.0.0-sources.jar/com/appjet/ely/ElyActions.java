package com.appjet.ely;

import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3481;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Acciones que Ely realiza para el jugador. */
public final class ElyActions {

    private static final Set<class_2248> MENAS = Set.of(
        class_2246.field_10418, class_2246.field_29219,
        class_2246.field_10212, class_2246.field_29027,
        class_2246.field_27120, class_2246.field_29221,
        class_2246.field_10571, class_2246.field_29026,
        class_2246.field_10080, class_2246.field_29030,
        class_2246.field_10090, class_2246.field_29028,
        class_2246.field_10442, class_2246.field_29029,
        class_2246.field_10013, class_2246.field_29220,
        class_2246.field_10213, class_2246.field_23077,
        class_2246.field_22109
    );

    private static int tic = 0;

    private ElyActions() {
    }

    /** Corazones ambientales cuando Ely está muy enamorada. */
    public static void tick(MinecraftServer servidor) {
        tic++;
        if (tic % 100 != 0) {
            return;
        }
        ElyState estado = ElyState.get(servidor);
        for (class_3222 jugador : servidor.method_3760().method_14571()) {
            if (estado.afinidad(jugador.method_5667()) < 75) {
                continue;
            }
            jugador.method_51469().method_14199(
                class_2398.field_11201,
                jugador.method_23317(), jugador.method_23318() + 2.2, jugador.method_23321(),
                2, 0.35, 0.25, 0.35, 0.0
            );
        }
    }

    // --- acciones del bosque ------------------------------------------------

    public static void picar(class_3222 jugador) {
        class_3218 mundo = jugador.method_51469();
        class_2338 base = jugador.method_24515();
        List<class_2338> troncos = new ArrayList<>();

        for (class_2338 pos : class_2338.method_10097(base.method_10069(-4, -1, -4), base.method_10069(4, 3, 4))) {
            if (troncos.size() >= 16) {
                break;
            }
            if (mundo.method_8320(pos).method_26164(class_3481.field_15475)) {
                troncos.add(pos.method_10062());
            }
        }

        if (troncos.isEmpty()) {
            jugador.method_7353(class_2561.method_43471("elylang.accion.picar.vacio").method_27692(class_124.field_1080), false);
            return;
        }

        for (class_2338 pos : troncos) {
            mundo.method_8651(pos, true, jugador);
        }
        mundo.method_8396(null, base, class_3417.field_15215, class_3419.field_15248, 1.0f, 1.0f);

        jugador.method_7353(class_2561.method_43469("elylang.accion.picar.ok", troncos.size()).method_27692(class_124.field_1060), false);
        premiar(jugador, 4);
    }

    public static void minar(class_3222 jugador) {
        class_3218 mundo = jugador.method_51469();
        class_2338 base = jugador.method_24515();
        List<class_2338> menas = new ArrayList<>();

        for (class_2338 pos : class_2338.method_10097(base.method_10069(-4, -8, -4), base.method_10069(4, 2, 4))) {
            if (menas.size() >= 12) {
                break;
            }
            class_2248 bloque = mundo.method_8320(pos).method_26204();
            if (MENAS.contains(bloque)) {
                menas.add(pos.method_10062());
            }
        }

        if (menas.isEmpty()) {
            jugador.method_7353(class_2561.method_43471("elylang.accion.minar.vacio").method_27692(class_124.field_1080), false);
            return;
        }

        for (class_2338 pos : menas) {
            mundo.method_8651(pos, true, jugador);
        }
        mundo.method_8396(null, base, class_3417.field_15026, class_3419.field_15248, 1.0f, 0.8f);

        jugador.method_7353(class_2561.method_43469("elylang.accion.minar.ok", menas.size()).method_27692(class_124.field_1060), false);
        premiar(jugador, 6);
    }

    public static void proteger(class_3222 jugador) {
        class_3218 mundo = jugador.method_51469();
        class_238 area = new class_238(jugador.method_24515()).method_1009(12.0, 6.0, 12.0);
        int derrotados = 0;

        for (class_1297 entidad : mundo.method_8335(jugador, area)) {
            if (!(entidad instanceof class_1588 hostil) || !hostil.method_5805()) {
                continue;
            }
            if (hostil.method_5739(jugador) > 12.0f) {
                continue;
            }
            mundo.method_14199(class_2398.field_11205, hostil.method_23317(), hostil.method_23318() + 1.0, hostil.method_23321(), 8, 0.3, 0.3, 0.3, 0.1);
            hostil.method_5643(mundo.method_48963().method_48831(), 8.0f);
            derrotados++;
        }

        if (derrotados == 0) {
            jugador.method_7353(class_2561.method_43471("elylang.accion.proteger.vacio").method_27692(class_124.field_1080), false);
            return;
        }

        mundo.method_8396(null, jugador.method_24515(), class_3417.field_15150, class_3419.field_15248, 1.0f, 1.2f);
        jugador.method_7353(class_2561.method_43469("elylang.accion.proteger.ok", derrotados).method_27692(class_124.field_1060), false);
        premiar(jugador, 6);
    }

    public static void flor(class_3222 jugador) {
        jugador.method_31548().method_7394(new class_1799(class_1802.field_8880, 2));
        jugador.method_31548().method_7394(new class_1799(class_1802.field_17513, 1));
        jugador.method_51469().method_14199(
            class_2398.field_11201,
            jugador.method_23317(), jugador.method_23318() + 1.5, jugador.method_23321(),
            6, 0.4, 0.4, 0.4, 0.0
        );
        jugador.method_7353(class_2561.method_43471("elylang.accion.flor.ok").method_27692(class_124.field_1076), false);
        premiar(jugador, 5);
    }

    public static void acariciar(class_3222 jugador) {
        corazones(jugador.method_51469(), jugador, 6);
        jugador.method_7353(class_2561.method_43471("elylang.accion.acariciar.ok").method_27692(class_124.field_1076), false);
        premiar(jugador, 3);
    }

    // --- romance no explícito ----------------------------------------------

    /** Devuelve el motivo por el que la noche no puede ocurrir, o null si puede. */
    public static class_2561 bloqueoIntimidad(class_3222 jugador) {
        ElyState estado = ElyState.get(jugador.method_5682());
        if (!estado.esAdulto(jugador.method_5667())) {
            return class_2561.method_43471("elylang.accion.intimidad.menor").method_27692(class_124.field_1061);
        }
        int afinidad = estado.afinidad(jugador.method_5667());
        if (afinidad < 75) {
            return class_2561.method_43469("elylang.accion.intimidad.afinidad", afinidad).method_27692(class_124.field_1054);
        }
        class_3218 mundo = jugador.method_51469();
        long ahora = mundo.method_8510();
        long ultima = estado.ultimaIntimidad(jugador.method_5667());
        long transcurrido = ahora - ultima;
        if (transcurrido < ElyState.RECARGA_INTIMIDAD) {
            long falta = ElyState.RECARGA_INTIMIDAD - transcurrido;
            return class_2561.method_43469("elylang.accion.intimidad.espera", (falta / 20L) / 60L).method_27692(class_124.field_1054);
        }
        if (!mundo.method_23886()) {
            return class_2561.method_43471("elylang.accion.intimidad.dia").method_27692(class_124.field_1054);
        }
        return null;
    }

    /**
     * Noche de pasión: se resuelve con un fundido a negro. No se describe
     * ningún contenido sexual explícito, solo afecto y consecuencias en el juego.
     */
    public static void intimidad(class_3222 jugador) {
        class_2561 bloqueo = bloqueoIntimidad(jugador);
        if (bloqueo != null) {
            jugador.method_7353(bloqueo, false);
            return;
        }

        ElyState estado = ElyState.get(jugador.method_5682());
        estado.marcarIntimidad(jugador.method_5667(), jugador.method_51469().method_8510());

        fundido(jugador,
            class_2561.method_43471("elylang.accion.intimidad.titulo"),
            class_2561.method_43471("elylang.accion.intimidad.subtitulo"));

        jugador.method_6092(new class_1293(class_1294.field_5924, 200, 1));
        corazones(jugador.method_51469(), jugador, 12);

        jugador.method_7353(class_2561.method_43471("elylang.accion.intimidad.ok").method_27692(class_124.field_1076), false);
        premiar(jugador, 10);
    }

    // --- utilidades ---------------------------------------------------------

    private static void premiar(class_3222 jugador, int delta) {
        ElyState estado = ElyState.get(jugador.method_5682());
        int nueva = estado.sumarAfinidad(jugador.method_5667(), delta);
        jugador.method_7353(
            class_2561.method_43469("elylang.accion.afinidad", "+" + delta, nueva).method_27692(class_124.field_1076),
            false
        );
    }

    private static void corazones(class_3218 mundo, class_1309 centro, int cantidad) {
        mundo.method_14199(
            class_2398.field_11201,
            centro.method_23317(), centro.method_23318() + 1.8, centro.method_23321(),
            cantidad, 0.5, 0.5, 0.5, 0.0
        );
    }

    private static void fundido(class_3222 jugador, class_2561 titulo, class_2561 subtitulo) {
        jugador.field_13987.method_14364(new class_5905(10, 40, 20));
        jugador.field_13987.method_14364(new class_5904(titulo));
        jugador.field_13987.method_14364(new class_5903(subtitulo));
    }
}
